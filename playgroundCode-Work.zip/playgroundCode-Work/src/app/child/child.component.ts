import { Component, Input, OnInit } from '@angular/core';
import { QuestionanaireModel } from '../models/questionnaire';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent {

  @Input() formData: QuestionanaireModel = QuestionanaireModel.creatBlankQuestionnaire();
  dateFl = new Date().toJSON().substring(0, 10);

}

